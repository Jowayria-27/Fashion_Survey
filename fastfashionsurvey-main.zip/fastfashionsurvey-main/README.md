# fastfashionsurvey
A  gamified fast fashion survey
